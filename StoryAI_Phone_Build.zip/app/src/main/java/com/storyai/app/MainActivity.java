package com.storyai.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private TextView status, plan;
    private EditText topic;
    private final Handler handler = new Handler();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        topic = findViewById(R.id.topic);
        status = findViewById(R.id.status);
        plan = findViewById(R.id.plan);

        Spinner language = findViewById(R.id.language);
        ArrayAdapter<String> la = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"العربية","الدارجة المغربية","English","Français","Español","Deutsch","Türkçe"});
        language.setAdapter(la);

        Spinner duration = findViewById(R.id.duration);
        ArrayAdapter<String> du = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"10 دقائق","30 دقيقة","60 دقيقة","90 دقيقة","120 دقيقة"});
        duration.setAdapter(du);

        findViewById(R.id.generate).setOnClickListener(v -> startPipeline());
    }

    private void startPipeline() {
        String t = topic.getText().toString().trim();
        if (t.isEmpty()) { topic.setError("اكتب فكرة القصة"); return; }

        status.setText("جاري إعداد المشروع...");
        plan.setText("1) كتابة السيناريو\n2) تقسيم القصة إلى مشاهد\n3) تجهيز التعليق الصوتي\n4) تجهيز الصور/المقاطع\n5) تركيب الفيديو الطويل\n\nهذه النسخة هي واجهة البداية؛ ربط نماذج التوليد المحلية/المجانية يتم في المرحلة التالية.");

        handler.postDelayed(() -> status.setText("تم إنشاء مخطط القصة — جاهز لربط محرك AI"), 1800);
    }
}
